package com.example.myapplication.database

data class MineFiled (
    val level : Int,
    val cells : List<Cell>
)

data class Cell(
    var isOpened : Boolean = false,
    var isMarked: Boolean = false,
    val status: Int
)