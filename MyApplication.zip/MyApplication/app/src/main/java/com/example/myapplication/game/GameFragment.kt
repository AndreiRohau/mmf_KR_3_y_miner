package com.example.myapplication.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.R
import com.example.myapplication.databinding.GameFragmentBinding
import kotlinx.android.synthetic.main.game_fragment.*

class GameFragment : Fragment() {

    private var level : Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //val viewModel = ViewModelProvider(this).get(GameViewModel::class.java)
        //viewModel.startLevel()
        val binding = DataBindingUtil.inflate<GameFragmentBinding>(inflater, R.layout.game_fragment, container, false)
        binding.setLifecycleOwner(this)
//        binding.gameViewModel = viewModel

        val adapter = CellAdapter()

        binding.startButton.setOnClickListener() {
            //Toast.makeText(activity,"Clicked", Toast.LENGTH_LONG).show()
            binding.level.text = adapter.startLevel().toString()
        }

        binding.exit.setOnClickListener() {
            this.activity?.finish()
        }



        binding.gridView.adapter = adapter

        binding.gridView.numColumns = 10
        binding.gridView.horizontalSpacing = 10
        binding.gridView.verticalSpacing = 10
        binding.gridView.stretchMode = GridView.STRETCH_COLUMN_WIDTH

        return binding.root
    }


}
