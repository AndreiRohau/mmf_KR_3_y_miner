package com.example.myapplication.game

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.myapplication.database.Cell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {
    private var _cells = MutableLiveData<Array<Cell?>>()
    val cells: LiveData<Array<Cell?>>
        get() = _cells

    private var level: Int = 0

    private var _gameStarted = MutableLiveData<Boolean>()
    val gameStarted: LiveData<Boolean>
        get() = _gameStarted

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    fun startLevel() {
       // _cells.value = getLevelField(++level)
//        uiScope.launch {
//
//            _gameStarted.value = true
//        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }
}
