package com.example.myapplication.util

import android.util.Log
import com.example.myapplication.database.Cell
import java.util.*

const val LEVEL_MULTIPLIER = 5
//
//fun getLevelField(level: Int): Array<Cell?> {
//    val cells = arrayOfNulls<Cell>(100)
//    spreadMines(LEVEL_MULTIPLIER * (level + 1), cells)
//    putHints(cells)
//    return cells
//}
//
//fun openCells(index: Int, cells: Array<Cell?>){
//    val cellsToOpen = mutableSetOf<Int>()
//    processRecurtion(mutableSetOf<Int>(), mutableSetOf<Int>(index), cells, cellsToOpen)
//    cellsToOpen.forEach{
//        cells[it]?.isOpened = true
//    }
//}
//
//private fun spreadMines(amount: Int, cells: Array<Cell?>) {
//    var amount = amount
//    while (amount > 0) {
//        val position = Random().nextInt(100)
//        if (cells[position] == null) {
//            cells[position] = Cell(status = -1)
//            amount--
//        }
//    }
//}
//
//private fun putHints(cells: Array<Cell?>) {
//    for (i in 0..99) {
//        if (cells[i] == null) {
//            cells[i] = Cell(status = calcHint(cells, getNeighbours(i, cells)))
//        }
//    }
//}
//
//private fun calcCorner(sequence: Sequence<Int>, cells: Array<Cell?>): Int {
//    var hint = 0
//    for (i in sequence) {
//        if (cells[i]?.status == -1) hint++
//    }
//    return hint
//}
//
//private fun calcHint(cells: Array<Cell?>, indexes: Array<Int>) : Int {
//    var hint = 0
//    indexes.forEach {
//        if (cells[it]?.status == -1) hint++
//    }
//    return hint
//}
//
////private fun getIndexesToOpen(i: Int, cells: Array<Cell?>) {
////    val set = mutableSetOf<Int>()
////
////}
//
//private fun processRecurtion(processedZeros: MutableSet<Int>,
//                             beProcessedZeros: MutableSet<Int>,
//                             cells: Array<Cell?>,
//                             indexesToShow: MutableSet<Int>) {
//    beProcessedZeros.forEach {
//        val index = it
//        processedZeros.add(index)
//        if (!indexesToShow.contains(index)) {
//            indexesToShow.add(index)
//        }
//        val array = getNeighbours(index, cells)
//        val newZeros = mutableSetOf<Int>()
//        for (neighbour in array) {
//            if (!indexesToShow.contains(neighbour)) {
//                indexesToShow.add(neighbour)
//            }
//            if (cells[neighbour]?.status == 0 &&
//                !processedZeros.contains(neighbour) &&
//                !beProcessedZeros.contains(neighbour)) {
//                newZeros.add(neighbour)
//            }
//        }
//        processRecurtion(processedZeros, newZeros, cells, indexesToShow)
//    }
//}
//
//private fun calcRightLeft(position: Int) = arrayOf(position - 1, position, position + 1)
//
//private fun calcUpDown(position: Int) = arrayOf(position - 10, position, position + 10)
//
//private fun calcRound(position: Int): Array<Int> =
//    calcUpDown(position-1).plus(calcUpDown(position)).plus(calcUpDown(position+1))
//
//private fun getNeighbours(i: Int, cells: Array<Cell?>) : Array<Int> {
//    val rightBorder = sequenceOf(19, 29, 39, 49, 59, 69, 79, 89)
//    val leftBorder = sequenceOf(10, 20, 30, 40, 50, 60, 70, 80)
//    val topBorder = 1..8
//    val bottomBorder = 91..98
//
//    val indexes = when (i) {
//        0 -> arrayOf(1, 10, 11)
//        9 -> arrayOf(8, 18, 19)
//        90 -> arrayOf(80, 81, 91)
//        99 -> arrayOf(88, 89, 98)
//        in topBorder -> calcRightLeft(i).plus(calcRightLeft(i + 10))
//        in rightBorder -> calcUpDown(i).plus(calcUpDown(i - 1))
//        in leftBorder ->calcUpDown(i).plus(calcUpDown(i + 1))
//        in bottomBorder -> calcRightLeft(i).plus(calcRightLeft(i - 10))
//        else -> calcRound(i)
//    }
//    return indexes
//}
